import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import axios from 'axios';

export default function Home({ route }) {
  const { username } = route.params;
  const [valueBRL, setValueBRL] = useState('');
  const [convertedUSD, setConvertedUSD] = useState(null);
  const [convertedEUR, setConvertedEUR] = useState(null);

  const fetchRates = async () => {
    try {
      const response = await axios.get(
        'https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL'
      );
      const rates = response.data;
      const usdRate = parseFloat(rates.USDBRL.ask);
      const eurRate = parseFloat(rates.EURBRL.ask);

      setConvertedUSD((valueBRL * usdRate).toFixed(2));
      setConvertedEUR((valueBRL * eurRate).toFixed(2));
    } catch (error) {
      alert('Erro ao buscar as cotações.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>Olá, {username}!</Text>
      <Text style={styles.label}>Digite o valor em Reais (R$):</Text>
      <TextInput
        style={styles.input}
        placeholder="Ex: 100"
        keyboardType="numeric"
        value={valueBRL}
        onChangeText={setValueBRL}
      />
      <TouchableOpacity style={styles.button} onPress={fetchRates}>
        <Text style={styles.buttonText}>Converter</Text>
      </TouchableOpacity>
      {convertedUSD && (
        <View style={styles.resultBox}>
          <Text style={styles.resultText}>Dólar (USD): ${convertedUSD}</Text>
          <Text style={styles.resultText}>Euro (EUR): €{convertedEUR}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f4f4f4',
    padding: 16,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
    color: '#666',
  },
  input: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 20,
    borderRadius: 5,
    backgroundColor: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 12,
    borderRadius: 5,
    width: '60%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultBox: {
    marginTop: 20,
    backgroundColor: '#eaf8ff',
    padding: 15,
    borderRadius: 5,
    width: '80%',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 18,
    color: '#333',
    marginBottom: 5,
    fontWeight: 'bold',
  },
});
